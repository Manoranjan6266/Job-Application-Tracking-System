# Job Application Tracking System

A beginner-friendly Python Full Stack starter project using Django, MySQL, HTML, CSS and Bootstrap.

## Features
- User registration, login and logout
- Browse and search job listings
- View job details
- Apply for a job with an optional PDF/DOC/DOCX resume
- Track application status (Pending, Shortlisted, Rejected)
- Django admin to manage jobs and applications

## Requirements
- Python 3.10+
- MySQL Server and (optionally) MySQL Workbench
- VS Code

## 1. Create and activate a virtual environment

Windows:
```bash
python -m venv venv
venv\Scripts\activate
```

macOS/Linux:
```bash
python3 -m venv venv
source venv/bin/activate
```

## 2. Install packages
```bash
python -m pip install -r requirements.txt
```

## 3. Create the MySQL database

Run in MySQL Workbench:
```sql
CREATE DATABASE job_portal CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

Create a `.env` file by copying `.env.example`, then enter your MySQL password.
The project reads these values from environment variables. To set them in Windows PowerShell for the current terminal:
```powershell
$env:DB_NAME="job_portal"
$env:DB_USER="root"
$env:DB_PASSWORD="your_mysql_password"
$env:DB_HOST="127.0.0.1"
$env:DB_PORT="3306"
$env:DJANGO_SECRET_KEY="replace-with-a-long-random-secret"
$env:DEBUG="True"
```
On Windows CMD use `set DB_PASSWORD=your_mysql_password` (and similarly for the other variables).
On macOS/Linux use `export DB_PASSWORD='your_mysql_password'`.

## 4. Run migrations
```bash
python manage.py makemigrations jobs
python manage.py migrate
```

## 5. Create an admin account
```bash
python manage.py createsuperuser
```

## 6. Start the website
```bash
python manage.py runserver
```
Open http://127.0.0.1:8000/

Admin panel: http://127.0.0.1:8000/admin/

## Project structure
```text
Job_Application_Tracking_System/
├── accounts/
├── jobs/
├── jobportal/
├── media/
├── templates/
├── manage.py
└── requirements.txt
```

## Notes
- Never share your MySQL password or commit your `.env` file.
- This is a learning/development project. Before production deployment, configure a secure secret key, `DEBUG=False`, allowed hosts, HTTPS, secure cookies, email settings, and proper file-upload validation.
