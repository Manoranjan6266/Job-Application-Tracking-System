from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.forms import UserCreationForm
from django.shortcuts import redirect, render

def register_view(request):
    if request.user.is_authenticated:
        return redirect("job_list")
    if request.method == "POST":
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, "Your account was created successfully.")
            return redirect("job_list")
    else:
        form = UserCreationForm()
    return render(request, "accounts/register.html", {"form": form})
