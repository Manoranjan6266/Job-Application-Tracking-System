from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.db.models import Q
from django.shortcuts import get_object_or_404, redirect, render
from .models import Application, Job

def job_list(request):
    query = request.GET.get("q", "").strip()
    jobs = Job.objects.filter(is_active=True)
    if query:
        jobs = jobs.filter(
            Q(title__icontains=query) |
            Q(company__icontains=query) |
            Q(location__icontains=query) |
            Q(skills__icontains=query)
        )
    return render(request, "jobs/job_list.html", {"jobs": jobs, "query": query})

def job_detail(request, pk):
    job = get_object_or_404(Job, pk=pk, is_active=True)
    already_applied = request.user.is_authenticated and Application.objects.filter(job=job, applicant=request.user).exists()
    return render(request, "jobs/job_detail.html", {"job": job, "already_applied": already_applied})

@login_required
def apply_job(request, pk):
    job = get_object_or_404(Job, pk=pk, is_active=True)
    if request.method == "POST":
        if Application.objects.filter(job=job, applicant=request.user).exists():
            messages.warning(request, "You have already applied for this job.")
            return redirect("my_applications")
        resume = request.FILES.get("resume")
        if resume:
            allowed = (".pdf", ".doc", ".docx")
            if not resume.name.lower().endswith(allowed):
                messages.error(request, "Please upload a PDF, DOC or DOCX resume.")
                return redirect("job_detail", pk=job.pk)
            if resume.size > 5 * 1024 * 1024:
                messages.error(request, "Resume must be 5 MB or smaller.")
                return redirect("job_detail", pk=job.pk)
        Application.objects.create(
            job=job,
            applicant=request.user,
            resume=resume,
            cover_letter=request.POST.get("cover_letter", "").strip(),
        )
        messages.success(request, "Your application was submitted.")
        return redirect("my_applications")
    return redirect("job_detail", pk=job.pk)

@login_required
def my_applications(request):
    applications = Application.objects.filter(applicant=request.user).select_related("job")
    return render(request, "jobs/my_applications.html", {"applications": applications})
